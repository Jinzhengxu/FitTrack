# Barbells Detector > 2023-03-13 7:08pm
https://universe.roboflow.com/yolo-project-c2bfs/barbells-detector

Provided by a Roboflow user
License: CC BY 4.0

